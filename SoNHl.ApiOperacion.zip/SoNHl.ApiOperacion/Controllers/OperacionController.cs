﻿using Microsoft.AspNetCore.Mvc;
using SoNHl.ApiOperacion.Models;
using SoNHl.ApiOperacion.Models.DTOS;
using SoNHl.ApiOperacion.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SoNHl.ApiOperacion.Controllers
{
    [Route("[controller]/[action]")]
    public class OperacionController : ControllerBase
    {
        private IArticuloService _articuloService;
        public OperacionController(IArticuloService articuloService)
        {
            _articuloService = articuloService;
        }

        [HttpGet]
        public async Task<OperacionPaginadoDTO> Listar(int size, int numpag) {

            OperacionPaginadoDTO lista = 
                await _articuloService.ListarPaginado(size, numpag);
            return lista;
        }

        //[HttpGet]
        //public async Task<List<Operacion>> Listar()
        //{

        //    List<Operacion> lista = await _articuloService.Listar();
        //    return lista;
        //}

    }
}
