﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SoNHl.ApiOperacion.Models.DTOS
{
    public class OperationInsertResponseDTO
    {
        public int Codigo { get; set; }
        public DateTime Fecha { get; set; }
    }
}
