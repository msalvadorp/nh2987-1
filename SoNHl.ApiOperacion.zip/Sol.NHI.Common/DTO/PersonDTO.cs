﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Sol.NHI.Common.DTO
{
    public class PersonDTO
    {
        public int Codigo { get; set; }
        public string NombreCompleto { get; set; }

    }
}
